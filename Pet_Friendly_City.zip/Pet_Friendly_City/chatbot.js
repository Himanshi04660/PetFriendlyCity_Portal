document.getElementById("chat-open-btn").addEventListener("click", function () {
    alert("Hi! I'm PawBuddy 🐾 — here to help you learn more about the campaign!");
  });
  