document.querySelector("form").addEventListener("submit", function (e) {
    e.preventDefault();
    alert("Thanks for volunteering! 🐾");
  });
  